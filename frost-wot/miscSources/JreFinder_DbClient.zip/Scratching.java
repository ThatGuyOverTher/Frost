/*
 Scratching.java / Frost
 Copyright (C) 2007  Frost Project <jtcfrost.sourceforge.net>

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of
 the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

import java.io.*;
import java.net.*;
import java.util.*;

import frost.fcp.fcp07.*;

public class Scratching {

    public static void main(String[] args) throws Throwable {
        
        String jre = JreFinder.getJreExecutable("java");
        
        System.out.println("JRE="+jre);
        
        // bind a listen socket with a random port
        // start new jvm with workdir like frost, and provide port number
        // new jvm connects to us
        // send exit command to new jvm via socket
        
        Listener l = new Listener();
        int port = l.bindServerSocket();
        l.start();
        
        String cmd[] = new String[] { jre, "-cp", "C:\\Projects\\fr-wot\\_out_", "DbClient", ""+port};
        Runtime.getRuntime().exec(cmd);
        
    }
    
    /**
     * Handles communication with the client.
     * Opens ServerSocket, accepts 1 client, closes ServerSocket.
     * Talks with client. 
     * No restart of connection is possible! 
     */
    static class Listener extends Thread {
        
        private ServerSocket serverSocket;

        private Socket clientSocket = null;
        private PrintStream soOut = null;
        private BufferedInputStream soIn = null;

        public Listener() {
            super();
        }
        
        /** 
         * Binds a socket to a random port, returns the chosen port or -1 on error.
         */
        public int bindServerSocket() {
            int port = 12345;
            while(true) {
                try {
                    serverSocket = new ServerSocket(port, 1, InetAddress.getLocalHost());
                    break;
                } catch (IOException e) {
                    System.out.println("Could not listen on port "+port);
                    port++;
                    continue;
                }
            }
            return port;
        }

        public void run() {

            if( !listenForClient(serverSocket) ) {
                System.out.println("ERROR!");
                return;
            }

            System.out.println("Client connected");
            
            // client is connected, or error occured, close serversocket
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            // read all messages and handle them
            while(true) {
                NodeMessage nodeMsg = NodeMessage.readMessage(soIn);
                if( nodeMsg == null ) {
                    break; // socket closed
                } else {
                    // notify listeners
                    handleMessage(nodeMsg);
                }
            }
        }
        
        public boolean listenForClient(ServerSocket lServerSocket) {
            try {
                clientSocket = lServerSocket.accept();
                clientSocket.setSoTimeout(0); // on localhost, a crash always sends RST to the other one
                soOut = new PrintStream(clientSocket.getOutputStream(), false, "UTF-8");
                soIn = new BufferedInputStream(clientSocket.getInputStream());
            } catch (IOException e) {
                System.out.println("Accept failed");
                return false;
            }
            return true;
        }
        
        public boolean sendMessage(List<String> message, boolean sendEndMsg) {

            for(Iterator<String> i=message.iterator(); i.hasNext(); ) {
                String msgLine = i.next();
                soOut.println(msgLine);
//                System.out.println(msgLine);
            }
            if( sendEndMsg ) {
                soOut.println("EndMessage");
//                System.out.println("*EndMessage*");
            }
            boolean isError = soOut.checkError(); // flushes!
            return isError;
        }
        
        /**
         * Handle a received message.
         */
        private void handleMessage(NodeMessage msg) {
            
            if( msg.isMessageName("ClientHello") ) {
                // send a ServerHello
                ArrayList<String> answerMsg = new ArrayList<String>();
                answerMsg.add("ServerHello");
                sendMessage(answerMsg, true);
                
                // TODO: we can use the db now
     
            } else if( msg.isMessageName("StatusReply") ) {
                // client sent memory stats
                
            } else {
                // unknown message!
                System.out.println("* Unknown Message received: "+msg.getMessageName());
            }
        }
    }
}
