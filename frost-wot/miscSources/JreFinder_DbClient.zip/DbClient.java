import java.io.*;
import java.net.*;
import java.util.*;

import frost.fcp.fcp07.*;

/*
 DbClient.java / Frost
 Copyright (C) 2007  Frost Project <jtcfrost.sourceforge.net>

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of
 the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

public class DbClient {

    private Socket clientSocket = null;
    private PrintStream soOut = null;
    private BufferedInputStream soIn = null;

    public static void main(String[] args) {
        new DbClient().start(args[0]);
    }
    
    private void start(String arg0) {
        System.out.println("DbClient started");

        // args[0] must contain the port number
        try {
            connectToServer(arg0);
        } catch(Throwable t) {
            t.printStackTrace();
            return;
        }

        // start database
        new Thread() {
            public void run() {
                String arg[] = new String[] { "-conf", "store/applayerdb.conf" };
                com.mckoi.runtime.McKoiDBMain.main(arg);
            }
        }.start();

        // give server time to startup
        try {
            Thread.sleep(3000);
        } catch(Throwable t) {
        }
        
        // start the receiver
        new ReceiveThread(soIn).start();

        // after connect we start the handshake
        ArrayList<String> msg = new ArrayList<String>();
        msg.add("ClientHello");
        msg.add("name=DbClient");
        msg.addAll( getMemoryInfo() );
        sendMessage(msg, true);

        System.out.println("DbClient terminated");
    }
    
    private void connectToServer(String portStr) throws Throwable {
        int port = Integer.parseInt(portStr);

        clientSocket = new Socket(InetAddress.getLocalHost(), port);
        clientSocket.setSoTimeout(0); // on localhost, a crash always sends RST to the other one
        
        soOut = new PrintStream(clientSocket.getOutputStream(), false, "UTF-8");
        soIn = new BufferedInputStream(clientSocket.getInputStream());
    }

    /**
     * Sends a message.
     * @param message
     * @param sendEndMsg
     * @return
     */
    public boolean sendMessage(List<String> message, boolean sendEndMsg) {

        for(Iterator<String> i=message.iterator(); i.hasNext(); ) {
            String msgLine = i.next();
            soOut.println(msgLine);
//            System.out.println(msgLine);
        }
        if( sendEndMsg ) {
            soOut.println("EndMessage");
//            System.out.println("*EndMessage*");
        }
        boolean isError = soOut.checkError(); // flushes!
        return isError;
    }
    
    /**
     * Handle a received message.
     */
    private void handleMessage(NodeMessage msg) {
        
        if( msg.isMessageName("ServerHello") ) {
            // answer to our initial ClientHello, nothing to do
        } else if( msg.isMessageName("StatusQuery") ) {
            // server requested status
            ArrayList<String> answerMsg = new ArrayList<String>();
            answerMsg.add("StatusReply");
            answerMsg.addAll( getMemoryInfo() );
            sendMessage(answerMsg, true);
        } else if( msg.isMessageName("ShutDown") ) {
            // server requested that we shutdown our jvm
            shutdownNow();
        } else {
            // unknown message!
            ArrayList<String> answerMsg = new ArrayList<String>();
            answerMsg.add("ProtocolError");
            answerMsg.add("Message=Invalid message received: "+msg.getMessageName());
            sendMessage(answerMsg, true);
        }
    }
    
    private List<String> getMemoryInfo() {
        Runtime r = Runtime.getRuntime();
        List<String> l = new ArrayList<String>(5);
        l.add("FreeMemory=" + Long.toString(r.freeMemory()));
        l.add("TotalMemory=" + Long.toString(r.totalMemory()));
        l.add("MaxMemory=" + Long.toString(r.maxMemory()));
        return l;
    }
    
    private void shutdownNow() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
    
    private class ReceiveThread extends Thread {
        
        private final BufferedInputStream fcpInp;
        
        public ReceiveThread(BufferedInputStream newFcpInp) {
            super();
            this.fcpInp = newFcpInp;
        }

        public void run() {
            while(true) {
                NodeMessage nodeMsg = NodeMessage.readMessage(fcpInp);
                if( nodeMsg == null ) {
                    break; // socket closed
                } else {
                    // notify listeners
                    handleMessage(nodeMsg);
                }
            }
            System.out.println("ReceiveThread ended, shutting down");
            shutdownNow();
        }
    }
}
